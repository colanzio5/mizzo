/**
 * COLIN CASAZZA
 * CS570 - OPERATING SYSTEMS
 * CSSC1070
 * ASSIGNMENT FOUR
 * 4/16/19
 */
#include "mizzo.h"

int main(int argc, char* argv[])
{
    return mizzo(argc, argv);
}